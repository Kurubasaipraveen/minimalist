// Open the popup
document.getElementById('openPopup1').addEventListener('click', function() {
    document.getElementById('popup1').style.display = 'block';
});

// Close the popup
document.getElementById('closePopup1').addEventListener('click', function() {
    document.getElementById('popup1').style.display = 'none';
});

document.getElementById('openPopup2').addEventListener('click', function() {
    document.getElementById('popup2').style.display = 'block';
});

// Close the popup
document.getElementById('closePopup2').addEventListener('click', function() {
    document.getElementById('popup2').style.display = 'none';
});